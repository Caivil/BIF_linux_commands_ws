#!/bin/bash
echo "======================================"
echo "  Well done, $(whoami)!"
echo "  You made this script executable."
echo "  Date: $(date)"
echo "  Files in this folder: $(ls | wc -l)"
echo "======================================"
